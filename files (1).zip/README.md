# Discord NPC RP Bot

A Discord bot that manages NPC characters for roleplay servers with advanced lore management and context-aware responses.

## Features

- 🎭 **NPC Management**: Create and manage multiple NPCs
- 📖 **Lore System**: Import NPC and player lore from Google Docs
- 🗣️ **Smart Parsing**: Recognizes RP message formats:
  - `"Dialogue"` - In-character speech
  - `*Actions*` - Single asterisk for actions
  - `**Narration**` - Double asterisks for narration
  - `(OOC)` - Parentheses ignored for out-of-character
- 📜 **Context Awareness**: Bot reads recent messages for accurate responses
- 👥 **Player Lore**: Store background information for each player
- 🔐 **Admin Commands**: Owner-only commands for NPC management

## Setup

### Prerequisites
- Python 3.8+
- Discord Bot Token
- Google Docs links (for lore import)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/211487-ux/discord-npc-rp-bot.git
cd discord-npc-rp-bot